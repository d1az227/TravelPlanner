// MÓDULO CONSUMIDOR DE OPENTRIPMAP API (GARANTIZA 5 RECOMENDACIONES)
const API_KEY = '5ae2e3f221c38a28845f05b630bf183b0da66dff69c73efd20875df0';

export async function fetchAttractions(lat, lon) {
    const listUrl = `https://api.opentripmap.com/0.1/en/places/radius?radius=50000&lon=${lon}&lat=${lat}&format=json&limit=12&apikey=${API_KEY}`;
    const response = await fetch(listUrl);
    if (!response.ok) return [];
    const places = await response.json();

    const finalAttractions = [];
    for (const place of places) {
        if (finalAttractions.length >= 5) break;
        try {
            const detailUrl = `https://api.opentripmap.com/0.1/en/places/xid/${place.xid}?apikey=${API_KEY}`;
            const detailRes = await fetch(detailUrl);
            const detail = await detailRes.json();

            if (detail.name) {
                finalAttractions.push({
                    name: detail.name,
                    image: detail.preview?.source || 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=500',
                    category: detail.kinds ? detail.kinds.split(',')[0].replace('_', ' ') : 'Turismo',
                    description: detail.wikipedia_extracts?.text ? detail.wikipedia_extracts.text.substring(0, 110) + '...' : 'Lugar de alto valor cultural e histórico ideal para agendar en tu próximo viaje.'
                });
            }
        } catch {
            continue;
        }
    }
    return finalAttractions;
}