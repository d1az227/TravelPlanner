export async function fetchWeatherData(lat, lon) {
    const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
    if (!response.ok) throw new Error('Error al consultar el clima.');
    const data = await response.json();
    
    const weatherCodes = {
        0: 'Despejado ☀️', 1: 'Principalmente Despejado 🌤️', 2: 'Parcialmente Nublado ⛅', 3: 'Nublado ☁️',
        45: 'Niebla 🌫️', 51: 'Llovizna 🌧️', 61: 'Lluvia Ligera 🌧️', 63: 'Lluvia 🌧️', 71: 'Nieve ❄️', 95: 'Tormenta ⛈️'
    };

    return {
        temp: data.current_weather.temperature,
        wind: data.current_weather.windspeed,
        code: weatherCodes[data.current_weather.weathercode] || 'Variable 🌤️'
    };
}