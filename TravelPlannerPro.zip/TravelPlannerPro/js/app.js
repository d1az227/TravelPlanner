// CONTROLADOR CENTRAL DE EVENTOS Y RENDERIZADO DEL DOM

import { getStorageData, saveStorageData, saveToHistory, toggleFavoriteCountry, toggleFavoriteAttraction } from './storage.js';
import { fetchCountryData } from './countries.js';
import { fetchWeatherData } from './weather.js';
import { fetchCurrencyConversion } from './currency.js';
import { fetchAttractions } from './tourism.js';

let currentCountry = null;
let currentAttractions = [];

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    checkUserRegistration();
    initAppEvents();
    renderDashboardAndPanels();
});

function checkUserRegistration() {
    const user = getStorageData('user_profile');
    const welcomeMessage = document.getElementById('welcome-message');
    
    if (!user) {
        mostrarFormularioRegistro();
        const form = document.getElementById('register-form');
        if (form) {
            form.addEventListener('submit', handleRegister);
        }
    } else {
        cerrarFormularioRegistro();
        if (welcomeMessage) welcomeMessage.innerText = `👋 Bienvenido, ${user.name}`;
    }
}

function handleRegister(e) {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const country = document.getElementById('reg-country').value.trim();

    if (!name || !email || !country) return;

    const profile = { name, email, country };
    saveStorageData('user_profile', profile);

    cerrarFormularioRegistro();
    const welcomeMessage = document.getElementById('welcome-message');
    if (welcomeMessage) welcomeMessage.innerText = `👋 Bienvenido, ${profile.name}`;
    renderDashboardAndPanels();
}

function initAppEvents() {
    const searchForm = document.getElementById('search-form');
    if (searchForm) searchForm.addEventListener('submit', handleSearch);
    
    const amountInput = document.getElementById('currency-amount');
    const selectCurrency = document.getElementById('currency-select');
    if (amountInput) amountInput.addEventListener('input', updateCurrencyConversion);
    if (selectCurrency) selectCurrency.addEventListener('change', updateCurrencyConversion);
}

async function handleSearch(e) {
    e.preventDefault();
    const countryInput = document.getElementById('search-input').value.trim();
    const errorDiv = document.getElementById('error-message');
    const content = document.getElementById('destination-content');
    
    if (!countryInput) return;
    if (errorDiv) errorDiv.innerText = '';
    
    toggleLoader(true);
    if (content) content.style.display = 'none';

    try {
        // 1. Intentar obtener datos del país (Si este falla, no podemos seguir)
        currentCountry = await fetchCountryData(countryInput);
        saveToHistory(currentCountry.name);
        renderCountryInfo(currentCountry);
        updateCurrencyConversion();
    } catch (error) {
        toggleLoader(false);
        if (errorDiv) errorDiv.innerText = "No se pudo encontrar el destino solicitado. Intenta de nuevo.";
        return; // Corta la ejecución si el país no existe
    }

    // 2. Ejecutar Clima y Turismo de forma segura e independiente
    const [lat, lon] = currentCountry.latlng;

    // Consultar Clima con protección
    try {
        const weather = await fetchWeatherData(lat, lon);
        renderWeatherInfo(weather);
    } catch (weatherError) {
        console.error("Falló la API de Clima:", weatherError);
        renderWeatherInfo({ temp: '--', wind: '--', code: 'No disponible por error de servidor' });
    }

    // Consultar Atracciones con protección
    try {
        currentAttractions = await fetchAttractions(lat, lon);
        renderAttractions(currentAttractions);
    } catch (tourismError) {
        console.error("Falló la API de Turismo:", tourismError);
        renderAttractions([]); // Muestra un mensaje limpio de no disponible en la grilla
    }

    // 3. Mostrar la interfaz con lo que se haya logrado cargar
    toggleLoader(false);
    if (content) content.style.display = 'grid';
    renderDashboardAndPanels();
}
function toggleLoader(show) {
    const loader = document.getElementById('loader');
    if (loader) loader.style.display = show ? 'block' : 'none';
}

function mostrarFormularioRegistro() {
    const modal = document.getElementById('register-modal');
    if (modal) modal.style.display = 'flex';
}

function cerrarFormularioRegistro() {
    const modal = document.getElementById('register-modal');
    if (modal) modal.style.display = 'none';
}

function renderCountryInfo(c) {
    const detailsContainer = document.getElementById('country-details');
    if (!detailsContainer) return;

    detailsContainer.innerHTML = `
        <img src="${c.flag}" alt="Bandera de ${c.name}">
        <h3>${c.name}</h3>
        <p><strong>Capital:</strong> ${c.capital}</p>
        <p><strong>Región:</strong> ${c.region} (${c.subregion})</p>
        <p><strong>Población:</strong> ${c.population} hab.</p>
        <p><strong>Idioma principal:</strong> ${c.language}</p>
        <p><strong>Moneda:</strong> ${c.currencyName} (${c.currencyCode})</p>
    `;
    
    const targetCode = document.getElementById('target-currency-code');
    if (targetCode) targetCode.innerText = c.currencyCode;
    
    const btn = document.getElementById('btn-fav-country');
    if (btn) {
        const favs = getStorageData('fav_countries') || [];
        const isFav = favs.some(f => f.name === c.name);
        btn.innerText = isFav ? '❌ Eliminar de Favoritos' : '⭐ Guardar como Favorito';
        
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        newBtn.addEventListener('click', () => {
            toggleFavoriteCountry(c);
            renderCountryInfo(c);
            renderDashboardAndPanels();
        });
    }
}

function renderWeatherInfo(w) {
    const weatherContainer = document.getElementById('weather-details');
    if (weatherContainer) {
        weatherContainer.innerHTML = `
            <div style="font-size: 2.5rem; margin-bottom:10px;">🌡️ ${w.temp} °C</div>
            <p><strong>Estado:</strong> ${w.code}</p>
            <p><strong>Viento:</strong> ${w.wind} km/h</p>
        `;
    }
}

async function updateCurrencyConversion() {
    if (!currentCountry) return;
    const amount = parseFloat(document.getElementById('currency-amount').value) || 1;
    const from = document.getElementById('currency-select').value;
    const to = currentCountry.currencyCode;
    const resultElement = document.getElementById('currency-result');

    if (!resultElement) return;

    const rate = await fetchCurrencyConversion(from, to);
    if (rate !== null) {
        resultElement.innerText = `${amount.toLocaleString()} ${from} = ${(amount * rate).toLocaleString(undefined, {minimumFractionDigits: 2})} ${to}`;
    } else {
        resultElement.innerText = `Conversión no soportada de ${from} a ${to}.`;
    }
}

function renderAttractions(list) {
    const grid = document.getElementById('attractions-grid');
    if (!grid) return;
    grid.innerHTML = '';

    list.forEach(attr => {
        const favs = getStorageData('fav_attractions') || [];
        const isFav = favs.some(f => f.name === attr.name);

        const card = document.createElement('div');
        card.className = 'attr-card';
        card.innerHTML = `
            <img src="${attr.image}" alt="${attr.name}">
            <div class="attr-info">
                <div>
                    <h4>${attr.name}</h4>
                    <span>${attr.category}</span>
                    <p>${attr.description}</p>
                </div>
                <button class="btn btn-fav-attr" style="width:100%; background:${isFav ? '#e74c3c' : '#3498db'}">
                    ${isFav ? 'Quitar 📌' : 'Favorito 📌'}
                </button>
            </div>
        `;
        card.querySelector('.btn-fav-attr').addEventListener('click', () => {
            toggleFavoriteAttraction(attr);
            renderAttractions(list);
            renderDashboardAndPanels();
        });
        grid.appendChild(card);
    });
}

function renderDashboardAndPanels() {
    const user = getStorageData('user_profile');
    const history = getStorageData('search_history') || [];
    const favCountries = getStorageData('fav_countries') || [];
    const favAttractions = getStorageData('fav_attractions') || [];

    const dUser = document.getElementById('dash-username');
    if (dUser) dUser.innerText = user ? user.name.split(' ')[0] : '-';
    
    const cHist = document.getElementById('count-history');
    if (cHist) cHist.innerText = history.length;
    
    const cCount = document.getElementById('count-countries');
    if (cCount) cCount.innerText = favCountries.length;
    
    const cAttr = document.getElementById('count-attractions');
    if (cAttr) cAttr.innerText = favAttractions.length;

    const favCList = document.getElementById('fav-countries-list');
    if (favCList) {
        favCList.innerHTML = '';
        favCountries.forEach(c => {
            const li = document.createElement('li');
            li.innerHTML = `<div><img src="${c.flag}" style="width:30px; margin-right:8px;"> <strong>${c.name}</strong></div><button class="btn-delete">Eliminar</button>`;
            li.querySelector('.btn-delete').addEventListener('click', () => {
                toggleFavoriteCountry(c);
                if (currentCountry && currentCountry.name === c.name) renderCountryInfo(currentCountry);
                renderDashboardAndPanels();
            });
            favCList.appendChild(li);
        });
    }

    const favAList = document.getElementById('fav-attractions-list');
    if (favAList) {
        favAList.innerHTML = '';
        favAttractions.forEach(a => {
            const li = document.createElement('li');
            li.innerHTML = `<span>📍 ${a.name}</span><button class="btn-delete">Eliminar</button>`;
            li.querySelector('.btn-delete').addEventListener('click', () => {
                toggleFavoriteAttraction(a);
                if (currentAttractions.length > 0) renderAttractions(currentAttractions);
                renderDashboardAndPanels();
            });
            favAList.appendChild(li);
        });
    }

    const histList = document.getElementById('history-list');
    if (histList) {
        histList.innerHTML = '';
        history.slice(0, 5).forEach(h => {
            const li = document.createElement('li');
            li.innerHTML = `<span>🔍 ${h.country}</span> <small style="color:var(--text-secondary)">${h.date} - ${h.time}</small>`;
            histList.appendChild(li);
        });
    }
}

function initTheme() {
    const theme = getStorageData('theme_preference') || 'light';
    if (theme === 'dark') document.body.classList.add('dark-theme');
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            saveStorageData('theme_preference', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
        });
    }
}