export function getStorageData(key) {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
}

export function saveStorageData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

export function saveToHistory(countryName) {
    let history = getStorageData('search_history') || [];
    const now = new Date();
    const newEntry = {
        country: countryName,
        date: now.toLocaleDateString(),
        time: now.toLocaleTimeString()
    };
    if (history.length === 0 || history[0].country !== countryName) {
        history.unshift(newEntry);
        saveStorageData('search_history', history);
    }
}

export function toggleFavoriteCountry(country) {
    let favs = getStorageData('fav_countries') || [];
    const exists = favs.find(f => f.name === country.name);
    if (exists) {
        favs = favs.filter(f => f.name !== country.name);
    } else {
        favs.push({ name: country.name, flag: country.flag });
    }
    saveStorageData('fav_countries', favs);
}

export function toggleFavoriteAttraction(attr) {
    let favs = getStorageData('fav_attractions') || [];
    const exists = favs.find(f => f.name === attr.name);
    if (exists) {
        favs = favs.filter(f => f.name !== attr.name);
    } else {
        favs.push(attr);
    }
    saveStorageData('fav_attractions', favs);
}