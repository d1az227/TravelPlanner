// MÓDULO CONSUMIDOR DE FRANKFURTER API
export async function fetchCurrencyConversion(fromCurrency, toCurrency) {
    if (fromCurrency === toCurrency) return 1;
    try {
        const response = await fetch(`https://api.frankfurter.dev/latest?from=${fromCurrency}&to=${toCurrency}`);
        if (!response.ok) return null;
        const data = await response.json();
        return data.rates[toCurrency];
    } catch {
        return null;
    }
}