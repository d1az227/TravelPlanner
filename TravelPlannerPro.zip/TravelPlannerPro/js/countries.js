// MÓDULO CONSUMIDOR DE REST COUNTRIES API (BLINDADO)
export async function fetchCountryData(countryName) {
    const cleanName = countryName.trim();
    const response = await fetch(`https://restcountries.com/v3.1/name/${cleanName}`);
    
    if (!response.ok) throw new Error('País no encontrado.');
    
    const data = await response.json();
    const country = data[0];

    // Extracción segura de monedas para evitar bloqueos si la estructura varía
    let currencyCode = 'USD';
    let currencyName = 'No disponible';
    if (country.currencies) {
        currencyCode = Object.keys(country.currencies)[0];
        currencyName = country.currencies[currencyCode].name || currencyCode;
    }

    return {
        name: country.name.common,
        flag: country.flags.png,
        capital: country.capital ? country.capital[0] : 'N/A',
        region: country.region,
        subregion: country.subregion || 'N/A',
        population: country.population.toLocaleString(),
        currencyCode: currencyCode,
        currencyName: currencyName,
        language: country.languages ? Object.values(country.languages)[0] : 'N/A',
        latlng: country.latlng || [4.0, -73.0] // Coordenadas de respaldo de Colombia si fallan
    };
}